
const state = {
  analises: [],
  documentos: 0
};

function navigate(pageId) {
  document.querySelectorAll(".page").forEach(page => {
    page.classList.remove("active");
  });

  const page = document.getElementById(pageId);

  if (page) {
    page.classList.add("active");
  }

  document.querySelectorAll(".nav-item").forEach(button => {
    button.classList.toggle(
      "active",
      button.dataset.page === pageId
    );
  });
}

document.querySelectorAll(".nav-item").forEach(button => {
  button.addEventListener("click", () => {
    navigate(button.dataset.page);
  });
});

function selectArea(area) {
  document.getElementById("assunto").value = area;
  navigate("analise");
}

const zipInput = document.getElementById("zipFile");

zipInput.addEventListener("change", () => {
  const file = zipInput.files[0];

  const info = document.getElementById("fileInfo");

  if (!file) {
    info.textContent = "Nenhum arquivo selecionado.";
    return;
  }

  if (!file.name.toLowerCase().endsWith(".zip")) {
    zipInput.value = "";
    info.textContent = "Formato não permitido.";
    alert("Selecione um arquivo ZIP.");
    return;
  }

  const tamanho = (file.size / 1024 / 1024).toFixed(2);

  info.textContent =
    file.name + " | " + tamanho + " MB";
});

document.getElementById("prepareButton")
  .addEventListener("click", () => {

    const numero = document.getElementById("numero").value.trim();
    const assunto = document.getElementById("assunto").value;
    const arquivo = zipInput.files[0];
    const feedback = document.getElementById("feedback");

    if (!numero || !assunto || !arquivo) {
      feedback.textContent =
        "Preencha o protocolo, selecione o assunto e anexe um ZIP.";
      return;
    }

    const registro = {
      numero,
      assunto,
      arquivo: arquivo.name,
      data: new Date().toLocaleString("pt-BR")
    };

    state.analises.push(registro);
    state.documentos++;

    atualizarPainel();

    feedback.textContent =
      "Cadastro demonstrativo criado. Nenhum documento foi enviado ou analisado.";

    document.getElementById("numero").value = "";
    document.getElementById("assunto").value = "";
    document.getElementById("observacoes").value = "";
    zipInput.value = "";

    document.getElementById("fileInfo").textContent =
      "Nenhum arquivo selecionado.";
  });

function atualizarPainel() {
  document.getElementById("totalAnalises").textContent =
    state.analises.length;

  document.getElementById("totalDocumentos").textContent =
    state.documentos;

  document.getElementById("totalRelatorios").textContent = "0";

  const history = document.getElementById("historyList");

  history.replaceChildren();

  if (state.analises.length === 0) {
    history.textContent = "Nenhuma análise registrada.";
    return;
  }

  state.analises.forEach(item => {
    const element = document.createElement("div");
    element.className = "history-item";

    const title = document.createElement("strong");
    title.textContent = "Protocolo: " + item.numero;

    const details = document.createElement("p");
    details.textContent =
      item.assunto + " | " +
      item.arquivo + " | " + item.data;

    element.append(title, details);
    history.appendChild(element);
  });
}
